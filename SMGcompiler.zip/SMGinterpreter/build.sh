#!/usr/bin/env bash
set -e
rm -f SMGcompiler.exe
rm -f SMGcompiler.luastatic.c
./luajit luastatic/luastatic.lua source/SMGcompiler.lua JIT/src/libluajit.a JIT/src
gcc SMGcompiler.luastatic.c -o SMGcompiler.exe JIT/src/libluajit.a -I JIT/src -lwinmm -lpsapi