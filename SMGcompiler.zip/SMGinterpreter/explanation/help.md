**hi guys!**
its me, mangykirb.
so as always, i was bored so i decided to make a interpreter... but its a bit different
you see, its a assembly-inspired language because its basic as heck okay?
so i use this method
instead of running instructions directly
i do

**code -> assembly -> machine code**

and u got it without messing with the MZ signatures and other
i will use nasm.exe, and if you want, you can as always, grab only the exe. if ur a natural curious person, then u can consume everything
Overall its lightweight, if u will grab the zip, i think it will reach about 20MB or in between.

**so, how to use?**
ITS NEVER UI! NEVER! NEVER! NEVER!!!!!!!!!!!
its always CLI.
so if u want to compile ur file, heres what u do
in cmd prompt:
SMG -f YourFileName.smg
in powershell
./SMG -f YourFileName.smg

yes, thats it actually.
Tbh, its really similar to assembly
for global main, u do
glb main
remember! this is windows only, x86. i dont know about ARM or if its flexible against other OSes, but im lazy to check.

yeaa...
overall, its made in lua and of course, **LUAJIT!!!!!!!!!!!!!!!**

lua can print in like 300 microseconds or less in roblox studio (roblox studio uses lua)
and luajit makes lua like 10x faster or more

so you know what that means... **FAST INTERPRETER!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!**
so yea
for any info, comment it or whatever
star it if u like it or not, i dont care

btw this is licensed under a modified GNU v3 that if you dont want to publish a modified version of my project, its fine. but if u publish it, follow the rules by copying the same license. give credit or not, just dont claim it as yours.

**HELP**
For any help, like when ur running build.sh, and u see the following
==== Successfully built LuaJIT 2.1 ====
System nie może odnaleźć określonej ścieżki. -- im in poland so this varies
C compiler not found.

then u found the gold
if u dont see the new exe, try

gcc SMGcompiler.luastatic.c -o SMGcompiler.exe JIT/src/libluajit.a -I JIT/src -lwinmm -lpsapi
if you even have gcc.

if not, try
pacman -S gcc
idk how u do it for real, so this could work or not
remember! i use mingw64 for this cuz YES

**Why is SMG quite good?**
It is pretty good cuz lets be honest, the executable for the SMG file is literally under the size of gcc.exe, about 2MB or less. so lightweightness, check.
Speed is also crazy due to luaJIT and holy, it is
The source code is about 188
So yea, i made a programming language in 2 days :D

**Is SMG readable?**
For me, yez
If you know assembly, you know SMG cuz SMG is a bit more readable assembly
Still, i think SMG is like 1.5-5x slower than assembly, but its still like 6 cpu cycles (1.5 nanoseconds on a 4ghz cpu) to do one instruction in SMG.
Who knows? i didnt check it yet, but i will :D

For any info, comment on my repo and ill surely answer!
If u like this repo, then if you want, star my repo. Do it or not, if you will that will show respect. if you dont, thats still fine

**How a program looks like**
It looks like
4D 5A 90 00 03 00 00 00
04 00 00 00 FF FF 00 00
B8 00 00 00 00 00 00 00
40 00 00 00 00 00 00 00
Okay, this is a joke
It looks like this
glb main
yes, thats accepted
even
glb main
main:
set eax, 5 -- the -- isnt a comment, but set eax, 5 = mov eax, 5
plus eax, 3252
minus eax, 52
divide eax, 2
endmain
**NOTE MOST IMPORTANT**
NEVER RUN SMGCOMPILER OUTSIDE THE SOURCE FOLDER OR WITHOUT EVERY FILE! yes, its actually that huge
Ill think about trying to make it less fragile, but idk if its even possible

yeah thats it :D
goodluck :D
**END**
