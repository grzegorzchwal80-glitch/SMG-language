---@diagnostic disable: lowercase-global
local cmds = arg[1]
local fs = {}
function fs.write(path, data)
    local f = io.open(path, "wb")
    if not f then return false end
    f:write(data)
    f:close()
    return true
end

local function Interpreter(input)
    -- It just translates from:
    -- SMG -> Assembly -> Machine Code (executable)
    -- I will use nasm.exe cuz who is crazy enough to make their own assembler
    -- input is the SMG file
    -- okay boys, this will be huge

    local inpute = io.open(input, "r"):read("*a")
    -- now we boutta speedrun life

    if inpute == nil then
        error("Error: Input file is empty or could not be read.", 1)
        os.exit(1)
    end
    if string.find(inpute, "main:", 1, true) == nil then
        error("Couldnt find main. Perhaps u gave it a different name, like glb start or glb begin, or forgot to add it?",
            1)
        os.exit(1)
    end
    if string.find(inpute, "endmain", 1, true) == nil then
        error("Couldnt find endmain. Did you forget to add it?", 1)
        os.exit(1)
    end

    local insideMain = false
    local lineNumber = 0
    local asm = {}

    local header = {
        "section .text"
    }

    for line in inpute:gmatch("[^\r\n]+") do
        lineNumber = lineNumber + 1
        local trimmed = line:match("^%s*(.-)%s*$")

        -- detect main label
        if trimmed == "main:" then
            insideMain = true
            table.insert(asm, "main:")
        elseif trimmed == "endmain" then
            insideMain = false
            table.insert(asm, "ret")
            table.insert(asm, "; endmain")
        else
            if not insideMain then
                local allowed =
                    trimmed == "" or
                    trimmed:match("^%-%-") or
                    trimmed:match("^glb") or
                    trimmed:match("^dat%.") or
                    trimmed:match("^dd")

                if not allowed then
                    error("Error: Code found outside main at line " .. lineNumber, 1)
                end

                if trimmed:match("^dat%.") then
                    -- data section already added
                elseif trimmed:match("^%.text") then
                    -- text section already added
                elseif trimmed:match("^glb%s+(%S+)") then
                    local sym = trimmed:match("^glb%s+(%S+)")
                    table.insert(header, "global " .. sym)
                end
            else
                if trimmed ~= "" and not trimmed:match("^%-%-") then
                    local cmd, args = trimmed:match("^(%S+)%s*(.*)$")
                    local handler = smgToAsm[cmd]
                    if not handler then
                        error("Unknown instruction '" .. tostring(cmd) .. "' at line " .. lineNumber, 1)
                    end
                    table.insert(asm, handler(args, lineNumber))
                end
            end
        end
    end

    return table.concat(header, "\n") .. "\n" .. table.concat(asm, "\n")
end

-- we are summoning the beast before GTA VI frfr
local registers = { "eax", "ebx", "ecx", "edx", "esi", "edi", "esp", "ebp" }

-- SMG → ASM command table
smgToAsm = {

    -- set eax, 8  -> mov eax, 8
    set = function(args, lineNumber)
        local reg, val = args:match("(%w+)%s*,%s*(%S+)")
        if not reg or not val then
            error("Invalid set syntax at line " .. lineNumber)
        end

        -- string literal?
        local str = val:match('"(.-)"')
        if str then
            return "; set with string literal, handle in data section: " .. str
        end

        return "mov " .. reg .. ", " .. val
    end,

    plus = function(args)
        local reg, val = args:match("(%w+)%s*,%s*(%S+)")
        return "add " .. reg .. ", " .. val
    end,

    minus = function(args)
        local reg, val = args:match("(%w+)%s*,%s*(%S+)")
        return "sub " .. reg .. ", " .. val
    end,

    Times = function(args)
        return "mul " .. args
    end,

    divide = function(args)
        return "div " .. args
    end,

    go = function(args)
        return "jmp " .. args
    end,

    goiflseql = function(args)
        return "jle " .. args
    end,

    goeq = function(args)
        return "je " .. args
    end,

    gogreq = function(args)
        return "jge " .. args
    end,

    gogr = function(args)
        return "jg " .. args
    end,
}

if cmds == nil then
    print("Error: No command provided. Use -f <filename.smg>")
    os.exit(1)
end
if cmds == "-v" then
    print(
        "SMG programming language compiler v1.0.0 \n First known version by mangykirb. \n License: GNU v3 with exceptions.")
    os.exit(1)
end
if cmds == "-f" then
    local arg2 = arg[2]
    if arg2 == nil then
        print("Error: No filename provided after -f")
        os.exit(1)
    end

    if string.sub(arg2, -4) ~= ".smg" then
        print("Error: File must have a .smg extension")
        os.exit(1)
    end

    -- i had to disable okay? it was nessesary
    local file = io.open(arg2, "r")
    if not file then
        print("Error: Could not open file " .. arg2)
        os.exit(1)
    end

    local read = file:read("*a")
    file:close()

    if not string.find(read, "glb main", 1, true) then -- hmm i wonder why not is white not red like in boblox studio
        error("During line of glb ..., expected main not other.", 1)
        os.exit(1)
    end

    local asm = Interpreter(arg2)
    fs.write("data.asm", asm)
    os.execute(
        'cmd /c "cd C:\\Users\\PC\\Documents\\myProject\\Files\\SMGinterpreter\\source && ' ..
        'nasm -f win32 data.asm -o data.obj'
    )
end
