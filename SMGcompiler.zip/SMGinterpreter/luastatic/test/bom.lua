﻿-- this file starts with a byte order mark
os.exit(0)

