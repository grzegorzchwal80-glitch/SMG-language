#!/usr/bin/lua
os.exit(0)
