﻿#!/usr/bin/env/lua
-- this file starts with a byte order mark and a shebang
os.exit(0)

