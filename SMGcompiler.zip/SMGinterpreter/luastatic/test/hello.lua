print("hello")
os.exit(0)
