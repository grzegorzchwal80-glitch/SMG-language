local t = {...}
assert(#arg == 3 and #t == 3)
